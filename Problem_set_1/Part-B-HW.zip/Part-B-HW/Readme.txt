To import the start code into Android Studio:

i) start AS, under a project e.g. ‘App01’, create a new Java application module for the problem, e.g., ‘ps1b’.  you should see that under ps1b, there is ‘java’ folder, with package ‘com.example’

ii) in Windows explorer / Mac Finder, copy the folders:

Part-B-HW/src/piwords

to 

AndroidStudioProjects/App01/ps1b/src/main/java
(App01 is the name of the project)

iii) after the copying, you could see the package ‘piwords’ under the ‘java’ folder. 

iv) after you have finished the programs, you can copy the entire piwords folder, zip it and submit

 



